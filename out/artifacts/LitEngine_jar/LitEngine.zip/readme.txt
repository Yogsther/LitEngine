How to play:

Menu:
Navigate: Up & Down arrows
Choose option: Enter

Player 1:

Movement: W,A,S,D
Shoot: Spacebar

Player 2:

Movement: Arrow keys
Shoot: Shift (Left or Right (right recommended.))


----


Objective:

The first player to get the oponent down to 0 health wins.


---

How to run:
"Double click the mouse" (LitEngine-TechDemo.jar)